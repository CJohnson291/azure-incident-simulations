# Azure Incident Simulation - Windows Environment

A standalone Windows Server 2022 VM environment for mid-tier incident
simulation scenarios, separate from the Linux baseline environment.

## What this deploys

- Resource group `rg-incidentsim-windows`
- VNet (10.51.0.0/16) + subnet (10.51.1.0/24)
- NSG allowing inbound RDP (from your IP only) and HTTP (80) from anywhere
- Public IP (Static, Standard SKU)
- Windows Server 2022 Datacenter VM (Standard_B2s_v2)

## Cost

Standard_B2s_v2 Windows Server is roughly £0.08-0.10/hour (~£60-70/month
if left running 24/7). Destroy after each scenario session to keep costs
to a few pence per session.

## Usage

1. Get your current public IP:
   ```bash
   curl -4 ifconfig.me
   ```

2. Create a `terraform.tfvars` file (not committed):
   ```hcl
   admin_password   = "YourStr0ng!Password"
   allowed_rdp_cidr = "x.x.x.x/32"
   ```

   Password requirements: min 12 chars, must include uppercase,
   lowercase, number, and special character.

3. Deploy:
   ```bash
   cd windows/
   terraform init
   terraform apply
   ```

4. Post-deploy checks:
   ```bash
   # Confirm correct public IP
   az network public-ip show \
     --resource-group rg-incidentsim-windows \
     --name pip-incidentsim-windows-app1 \
     --query ipAddress \
     --output tsv

   # Confirm NSG is associated to NIC
   az network nic show \
     --resource-group rg-incidentsim-windows \
     --name nic-incidentsim-windows-app1 \
     --query "networkSecurityGroup.id" \
     --output tsv
   ```

5. Connect via RDP:
   - Open Remote Desktop Connection on Mac (Microsoft Remote Desktop app)
   - Connect to the public IP on port 3389
   - Username: azureadmin
   - Password: as set in terraform.tfvars

6. Tear down after each scenario:
   ```bash
   terraform destroy
   ```

## Notes

- State is stored in the same Azure Blob backend as the Linux environment
  but under a separate key (`incidentsim-windows.terraform.tfstate`)
- RDP access is restricted to your IP via NSG — update if your IP changes
- Windows VMs cost roughly 2x Linux VMs — destroy promptly after sessions
